int main() {
    float x = 3.14;
    int y = 10;
    if (x > y) {
        y = y + 1;
    }
    return 0;
}
