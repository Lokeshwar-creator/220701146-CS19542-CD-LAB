int main() {
    // This is a comment
    float num = 3.14;
    int count = 10;
    /* Multi-line
       Comment */
    if (num > count) {
        count = count + 1;
    }
    return 0;
}
